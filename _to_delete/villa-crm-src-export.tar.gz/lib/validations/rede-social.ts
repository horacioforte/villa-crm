import { z } from "zod";

export const redeSocialTipoValues = ["INSTAGRAM", "FACEBOOK", "YOUTUBE"] as const;

export const REDE_SOCIAL_LABELS: Record<(typeof redeSocialTipoValues)[number], string> = {
  INSTAGRAM: "Instagram",
  FACEBOOK: "Facebook",
  YOUTUBE: "YouTube",
};

export const redeSocialStatusConexaoValues = [
  "NAO_CONECTADO",
  "CONECTADO",
  "ERRO",
  "TOKEN_EXPIRADO",
] as const;

export const STATUS_CONEXAO_LABELS: Record<
  (typeof redeSocialStatusConexaoValues)[number],
  string
> = {
  NAO_CONECTADO: "Não conectado",
  CONECTADO: "Conectado",
  ERRO: "Erro",
  TOKEN_EXPIRADO: "Token expirado",
};

const optionalNonEmptyText = z
  .union([z.string(), z.null(), z.undefined()])
  .transform((value) => {
    if (!value) return undefined;
    const trimmed = value.trim();
    return trimmed ? trimmed : undefined;
  });

export const criarRedeSocialContaSchema = z.object({
  rede: z.enum(redeSocialTipoValues),
  nome: z
    .string()
    .trim()
    .min(1, "Informe um nome para identificar a conta."),
  businessId: optionalNonEmptyText,
  pageId: optionalNonEmptyText,
  contaAnunciosId: optionalNonEmptyText,
  accessTokenEnvVar: optionalNonEmptyText,
});

export type CriarRedeSocialContaInput = z.input<typeof criarRedeSocialContaSchema>;
