"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarCheck,
  Check,
  ChevronDown,
  ChevronRight,
  Clock3,
  Edit,
  History,
  Loader2,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";

import type {
  PrioridadeTarefa,
  StatusTarefa,
  TipoAtividade,
} from "@/app/generated/prisma/client";
import { PageNavigation } from "@/components/layout/PageNavigation";
import {
  OportunidadeModal,
  type OportunidadePrefill,
} from "@/components/kanban/OportunidadeModal";
import {
  PRIORIDADE_CONFIG,
  STATUS_TAREFA_CONFIG,
  TIPO_CONFIG,
  TIPOS_RAPIDOS,
} from "@/components/tarefas/tarefa-config";
import {
  TarefaModal,
  type TarefaModalData,
} from "@/components/tarefas/TarefaModal";
import { temCadencia } from "@/lib/tarefas/cadencia";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { ConcluirTarefaDialog } from "@/components/tarefas/ConcluirTarefaDialog";

type Tarefa = TarefaModalData & {
  status: StatusTarefa;
  createdAt: string;
  concluidaEm: string | null;
  responsavel: { id: string; nome: string; email: string | null } | null;
  empresa: { id: string; razaoSocial: string; nomeFantasia: string | null } | null;
  oportunidade: { id: string; titulo: string; status: string } | null;
  obra: { id: string; nome: string } | null;
  pessoa: { id: string; nome: string } | null;
};

type UsuarioFiltro = {
  id: string;
  nome: string;
  ativo: boolean;
};

type TarefaContadores = {
  atrasadas: number;
  hoje: number;
  amanha: number;
  concluidas: number;
};

type TabStatus = "PENDENTE" | "EM_ANDAMENTO" | "ATRASADA" | "CONCLUIDA";

type EventoHistorico = {
  id: string;
  icone: string;
  descricao: string;
  usuario: string | null;
  data: string;
  action: string;
};
type Periodo = "hoje" | "amanha" | "esta_semana" | "todas";

const tabs: Array<{ value: TabStatus; label: string }> = [
  { value: "PENDENTE", label: "Pendentes" },
  { value: "EM_ANDAMENTO", label: "Em andamento" },
  { value: "ATRASADA", label: "Atrasadas" },
  { value: "CONCLUIDA", label: "Concluidas" },
];

const periodos: Array<{ value: Periodo; label: string }> = [
  { value: "hoje", label: "Hoje" },
  { value: "amanha", label: "Amanha" },
  { value: "esta_semana", label: "Esta semana" },
  { value: "todas", label: "Todas" },
];

function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function isSameDay(value: string | Date, reference = new Date()) {
  const date = new Date(value);
  return date.toDateString() === reference.toDateString();
}

function isThisWeek(value: string | Date) {
  const date = new Date(value);
  const today = startOfToday();
  const day = today.getDay() || 7;
  const weekStart = addDays(today, 1 - day);
  const weekEnd = addDays(weekStart, 6);
  weekEnd.setHours(23, 59, 59, 999);

  return date >= weekStart && date <= weekEnd;
}

function formatDate(value: string | Date) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
  }).format(new Date(value));
}

function corPrazo(dataVencimento: string | Date, status: StatusTarefa) {
  if (status === "CONCLUIDA") {
    return "text-emerald-600";
  }

  const vencimento = new Date(dataVencimento);

  if (vencimento < startOfToday()) {
    return "font-bold text-red-600";
  }

  if (isSameDay(vencimento)) {
    return "font-medium text-amber-600";
  }

  return "text-[#667085]";
}

function getEmpresaName(tarefa: Tarefa) {
  return tarefa.empresa
    ? (tarefa.empresa.nomeFantasia ?? tarefa.empresa.razaoSocial)
    : "Sem empresa";
}

function getContextBadges(tarefa: Tarefa) {
  return [
    tarefa.empresa
      ? {
          icon: "🏢",
          label: tarefa.empresa.nomeFantasia ?? tarefa.empresa.razaoSocial,
        }
      : null,
    tarefa.obra ? { icon: "🏗️", label: tarefa.obra.nome } : null,
    tarefa.oportunidade
      ? { icon: "💼", label: tarefa.oportunidade.titulo }
      : null,
  ].filter(Boolean) as Array<{ icon: string; label: string }>;
}

function filterByPeriodo(tarefa: Tarefa, periodo: Periodo) {
  if (periodo === "todas") {
    return true;
  }

  if (periodo === "hoje") {
    return isSameDay(tarefa.dataVencimento);
  }

  if (periodo === "amanha") {
    return isSameDay(tarefa.dataVencimento, addDays(new Date(), 1));
  }

  return isThisWeek(tarefa.dataVencimento);
}

export default function TarefasPage() {
  const [tarefas, setTarefas] = useState<Tarefa[]>([]);
  const [usuarios, setUsuarios] = useState<UsuarioFiltro[]>([]);
  const [canFiltrarResponsavel, setCanFiltrarResponsavel] = useState(false);
  const [contadores, setContadores] = useState<TarefaContadores>({
    atrasadas: 0,
    hoje: 0,
    amanha: 0,
    concluidas: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [tarefaEditando, setTarefaEditando] = useState<Tarefa | null>(null);
  const [tarefaConcluindo, setTarefaConcluindo] = useState<Tarefa | null>(null);
  const [tarefaConvertendo, setTarefaConvertendo] = useState<Tarefa | null>(null);
  const [oportunidadeModalAberto, setOportunidadeModalAberto] = useState(false);
  const [prefillOportunidade, setPrefillOportunidade] =
    useState<OportunidadePrefill | null>(null);
  const [concluirDialogOpen, setConcluirDialogOpen] = useState(false);
  const [tab, setTab] = useState<TabStatus>("PENDENTE");
  const [periodo, setPeriodo] = useState<Periodo>("hoje");
  // Histórico inline por tarefa
  const [tarefaExpandidaId, setTarefaExpandidaId] = useState<string | null>(null);
  const [historicos, setHistoricos] = useState<Record<string, EventoHistorico[]>>({});
  const [carregandoHistorico, setCarregandoHistorico] = useState<Record<string, boolean>>({});
  const historicoRef = useRef<Record<string, boolean>>({});
  const [responsavelId, setResponsavelId] = useState("todas");
  const [empresaId, setEmpresaId] = useState("todas");
  const [oportunidadeId, setOportunidadeId] = useState("todas");
  const [prioridade, setPrioridade] = useState<PrioridadeTarefa | "todas">(
    "todas",
  );
  const [tipo, setTipo] = useState<TipoAtividade | "todas">("todas");

  async function loadTarefas() {
    setIsLoading(true);

    try {
      const response = await fetch("/api/tarefas?status=todas&periodo=todas");

      if (!response.ok) {
        throw new Error("Falha ao carregar tarefas.");
      }

      setTarefas(await response.json());
    } catch {
      toast.error("Nao foi possivel carregar a agenda comercial.");
    } finally {
      setIsLoading(false);
    }
  }

  async function loadContadores(nextResponsavelId = responsavelId) {
    try {
      const params = new URLSearchParams();

      if (canFiltrarResponsavel && nextResponsavelId !== "todas") {
        params.set("responsavelId", nextResponsavelId);
      }

      const response = await fetch(
        `/api/tarefas/contadores${params.toString() ? `?${params}` : ""}`,
      );

      if (!response.ok) {
        throw new Error("Falha ao carregar contadores.");
      }

      setContadores(await response.json());
    } catch {
      toast.error("Nao foi possivel carregar os contadores de tarefas.");
    }
  }

  // Histórico inline — toggle + fetch com cache
  async function toggleHistorico(tarefaId: string) {
    if (tarefaExpandidaId === tarefaId) {
      setTarefaExpandidaId(null);
      return;
    }
    setTarefaExpandidaId(tarefaId);
    // Já carregado anteriormente — não busca de novo
    if (historicos[tarefaId] || historicoRef.current[tarefaId]) return;
    historicoRef.current[tarefaId] = true;
    setCarregandoHistorico((prev) => ({ ...prev, [tarefaId]: true }));
    try {
      const res = await fetch(`/api/tarefas/${tarefaId}/historico`);
      if (res.ok) {
        const data: EventoHistorico[] = await res.json();
        setHistoricos((prev) => ({ ...prev, [tarefaId]: data }));
      }
    } finally {
      setCarregandoHistorico((prev) => ({ ...prev, [tarefaId]: false }));
    }
  }

  useEffect(() => {
    let ignore = false;

    fetch("/api/tarefas?status=todas&periodo=todas")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Falha ao carregar tarefas.");
        }

        return response.json();
      })
      .then((data) => {
        if (!ignore) {
          setTarefas(data);
        }
      })
      .catch(() => {
        if (!ignore) {
          toast.error("Nao foi possivel carregar a agenda comercial.");
        }
      })
      .finally(() => {
        if (!ignore) {
          setIsLoading(false);
        }
      });

    return () => {
      ignore = true;
    };
  }, []);

  useEffect(() => {
    fetch("/api/usuarios")
      .then((response) => {
        if (!response.ok) {
          return null;
        }

        return response.json();
      })
      .then((data) => {
        if (!Array.isArray(data)) {
          return;
        }

        setCanFiltrarResponsavel(true);
        setUsuarios(
          data
            .filter((usuario: UsuarioFiltro) => usuario.ativo)
            .sort((left: UsuarioFiltro, right: UsuarioFiltro) =>
              left.nome.localeCompare(right.nome),
            ),
        );
      })
      .catch(() => {
        setCanFiltrarResponsavel(false);
      });
  }, []);

  /* eslint-disable react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */
  useEffect(() => {
    loadContadores();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canFiltrarResponsavel, responsavelId]);
  /* eslint-enable react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */

  const filtroOptions = useMemo(() => {
    const responsaveis = new Map<string, string>();
    const empresas = new Map<string, string>();
    const oportunidades = new Map<string, string>();

    for (const tarefa of tarefas) {
      if (tarefa.responsavel) {
        responsaveis.set(tarefa.responsavel.id, tarefa.responsavel.nome);
      }
      if (tarefa.empresa) {
        empresas.set(tarefa.empresa.id, getEmpresaName(tarefa));
      }
      if (tarefa.oportunidade) {
        oportunidades.set(tarefa.oportunidade.id, tarefa.oportunidade.titulo);
      }
    }

    return {
      responsaveis: canFiltrarResponsavel
        ? usuarios.map((usuario) => ({ id: usuario.id, label: usuario.nome }))
        : [...responsaveis].map(([id, label]) => ({ id, label })),
      empresas: [...empresas].map(([id, label]) => ({ id, label })),
      oportunidades: [...oportunidades].map(([id, label]) => ({ id, label })),
    };
  }, [canFiltrarResponsavel, tarefas, usuarios]);

  const tarefasFiltradas = useMemo(
    () =>
      tarefas.filter((tarefa) => {
        if (tarefa.status !== tab) {
          return false;
        }
        if (!filterByPeriodo(tarefa, periodo)) {
          return false;
        }
        if (responsavelId !== "todas" && tarefa.responsavelId !== responsavelId) {
          return false;
        }
        if (empresaId !== "todas" && tarefa.empresaId !== empresaId) {
          return false;
        }
        if (
          oportunidadeId !== "todas" &&
          tarefa.oportunidadeId !== oportunidadeId
        ) {
          return false;
        }
        if (prioridade !== "todas" && tarefa.prioridade !== prioridade) {
          return false;
        }
        if (tipo !== "todas" && tarefa.tipo !== tipo) {
          return false;
        }

        return true;
      }),
    [
      empresaId,
      oportunidadeId,
      periodo,
      prioridade,
      responsavelId,
      tab,
      tarefas,
      tipo,
    ],
  );

  async function deleteTarefa(tarefa: Tarefa) {
    if (!window.confirm("Excluir esta tarefa?")) {
      return;
    }

    try {
      const response = await fetch(`/api/tarefas/${tarefa.id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Falha ao excluir tarefa.");
      }

      setTarefas((current) => current.filter((item) => item.id !== tarefa.id));
      toast.success("Tarefa excluida.");
    } catch {
      toast.error("Nao foi possivel excluir a tarefa.");
    }
  }

  function openEdit(tarefa: Tarefa) {
    setTarefaEditando(tarefa);
    setModalAberto(true);
  }

  function openConcluir(tarefa: Tarefa) {
    setTarefaConcluindo(tarefa);
    setConcluirDialogOpen(true);
  }

  function openCreate() {
    setTarefaEditando(null);
    setModalAberto(true);
  }

  function handleConverterEmOportunidade(tarefa: Tarefa) {
    setTarefaConvertendo(tarefa);
    setPrefillOportunidade({
      empresaId: tarefa.empresaId,
      pessoaId: tarefa.pessoaId,
      obraId: tarefa.obraId,
      titulo: tarefa.titulo,
      canalOrigem: "OBRA_MAPEADA",
      usarTarefaExistenteComoPrimeiraAcao: true,
    });
    setOportunidadeModalAberto(true);
  }

  function closeOportunidadeModal() {
    setOportunidadeModalAberto(false);
    setPrefillOportunidade(null);
    setTarefaConvertendo(null);
  }

  return (
    <main className="min-h-screen bg-[#F4F6FA] px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <PageNavigation currentPage="Agenda comercial" currentHref="/tarefas" />

        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-[#1E4FAB]">
              Follow-up comercial
            </p>
            <h1 className="mt-2 text-3xl font-bold text-[#1A2E5A]">
              Agenda comercial
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-[#667085]">
              Controle proximas acoes, atrasos e responsaveis para nenhuma
              oportunidade ficar esquecida.
            </p>
          </div>

          <Button
            onClick={openCreate}
            className="h-11 rounded-2xl bg-[#1E4FAB] text-white hover:bg-[#1A2E5A]"
          >
            <Plus className="size-4" />
            Nova Tarefa
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          {[
            {
              label: "Atrasadas",
              value: contadores.atrasadas,
              icon: "🔴",
              className: "border-red-200 bg-red-50 text-red-700",
            },
            {
              label: "Hoje",
              value: contadores.hoje,
              icon: "🟡",
              className: "border-amber-200 bg-amber-50 text-amber-700",
            },
            {
              label: "Amanha",
              value: contadores.amanha,
              icon: "🔵",
              className: "border-blue-200 bg-blue-50 text-blue-700",
            },
            {
              label: "Concluidas hoje",
              value: contadores.concluidas,
              icon: "✅",
              className: "border-emerald-200 bg-emerald-50 text-emerald-700",
            },
          ].map((item) => (
            <Card key={item.label} className={cn("rounded-3xl", item.className)}>
              <CardHeader className="pb-2">
                <CardDescription>{item.label}</CardDescription>
                <CardTitle className="flex items-center gap-3 text-3xl">
                  <span>{item.icon}</span>
                  {item.value}
                </CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>

        <Card className="mt-6 rounded-3xl border-[#D7DEEA] bg-[#E8EEFB]">
          <CardContent className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#1E4FAB]">
                Cadencia comercial ativa
              </p>
              <p className="mt-1 text-sm text-[#1A2E5A]">
                Clique em Concluir / Cadencia para registrar o resultado e gerar
                automaticamente a proxima acao.
              </p>
            </div>
            <Badge className="w-fit rounded-2xl bg-[#1E4FAB] px-3 py-1 text-white">
              Proxima tarefa automatica
            </Badge>
          </CardContent>
        </Card>

        <Card className="mt-6 rounded-3xl border-[#D7DEEA]">
          <CardHeader>
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-[#1A2E5A]">
                  <CalendarCheck className="size-5 text-[#1E4FAB]" />
                  Tarefas
                </CardTitle>
                <CardDescription>
                  Use filtros rapidos para priorizar o dia comercial.
                </CardDescription>
              </div>
              {isLoading && (
                <div className="flex items-center gap-2 text-sm text-[#667085]">
                  <Loader2 className="size-4 animate-spin" />
                  Carregando
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="flex flex-wrap gap-2">
              {tabs.map((item) => (
                <Button
                  key={item.value}
                  type="button"
                  variant={tab === item.value ? "default" : "outline"}
                  onClick={() => setTab(item.value)}
                  className={cn(
                    "rounded-2xl",
                    tab === item.value && "bg-[#1A2E5A] text-white",
                  )}
                >
                  {item.label}
                </Button>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              {periodos.map((item) => (
                <Button
                  key={item.value}
                  type="button"
                  variant={periodo === item.value ? "default" : "outline"}
                  onClick={() => setPeriodo(item.value)}
                  className={cn(
                    "rounded-2xl",
                    periodo === item.value && "bg-[#1E4FAB] text-white",
                  )}
                >
                  {item.label}
                </Button>
              ))}
            </div>

            <details className="rounded-2xl border border-[#D7DEEA] bg-[#F4F6FA] p-4">
              <summary className="flex cursor-pointer items-center gap-2 font-semibold text-[#1A2E5A]">
                <ChevronDown className="size-4" />
                Filtros avancados
              </summary>
              <div className="mt-4 grid gap-3 md:grid-cols-5">
                {canFiltrarResponsavel ? (
                  <Select
                    value={responsavelId}
                    onValueChange={(value) => setResponsavelId(value ?? "todas")}
                  >
                    <SelectTrigger className="rounded-2xl">
                      <SelectValue placeholder="Responsavel" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Toda a equipe</SelectItem>
                      {filtroOptions.responsaveis.map((item) => (
                        <SelectItem key={item.id} value={item.id}>
                          {item.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : null}

                <Select
                  value={empresaId}
                  onValueChange={(value) => setEmpresaId(value ?? "todas")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Empresa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Empresa</SelectItem>
                    {filtroOptions.empresas.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={oportunidadeId}
                  onValueChange={(value) => setOportunidadeId(value ?? "todas")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Oportunidade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Oportunidade</SelectItem>
                    {filtroOptions.oportunidades.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={prioridade}
                  onValueChange={(value) =>
                    setPrioridade(value as PrioridadeTarefa | "todas")
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Prioridade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Prioridade</SelectItem>
                    {Object.entries(PRIORIDADE_CONFIG).map(([value, config]) => (
                      <SelectItem key={value} value={value}>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={tipo}
                  onValueChange={(value) =>
                    setTipo(value as TipoAtividade | "todas")
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Tipo</SelectItem>
                    {TIPOS_RAPIDOS.map((value) => {
                      const config = TIPO_CONFIG[value];

                      if (!config) {
                        return null;
                      }

                      return (
                        <SelectItem key={value} value={value}>
                          {config.emoji} {config.label}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </details>

            <div className="space-y-3">
              {tarefasFiltradas.length === 0 && !isLoading ? (
                <div className="rounded-3xl border border-dashed border-[#D7DEEA] bg-white p-8 text-center text-sm text-[#667085]">
                  Nenhuma tarefa encontrada para os filtros selecionados.
                </div>
              ) : (
                tarefasFiltradas.map((tarefa) => {
                  const tipoConfig = TIPO_CONFIG[tarefa.tipo] ?? {
                    emoji: "•",
                    label: "Tarefa",
                  };
                  const prioridadeConfig = PRIORIDADE_CONFIG[tarefa.prioridade];
                  const isConcluida = tarefa.status === "CONCLUIDA";
                  const hasCadencia = temCadencia(tarefa.tipo);
                  const prazoClassName = corPrazo(
                    tarefa.dataVencimento,
                    tarefa.status,
                  );
                  const contextBadges = getContextBadges(tarefa);

                  return (
                    <article
                      key={tarefa.id}
                      className={cn(
                        "rounded-3xl border border-[#D7DEEA] bg-white p-4 shadow-sm transition",
                        isConcluida && "opacity-60",
                      )}
                    >
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="flex gap-3">
                          <button
                            type="button"
                            onClick={() => openConcluir(tarefa)}
                            className={cn(
                              "mt-1 flex size-7 shrink-0 items-center justify-center rounded-full border border-[#D7DEEA] bg-white text-[#1E4FAB]",
                              isConcluida && "bg-emerald-100 text-emerald-700",
                            )}
                            aria-label="Concluir tarefa"
                          >
                            {isConcluida ? <Check className="size-4" /> : null}
                          </button>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xl">{tipoConfig.emoji}</span>
                              <h2
                                className={cn(
                                  "text-lg font-bold text-[#1A2E5A]",
                                  isConcluida && "line-through",
                                )}
                              >
                                {tarefa.titulo}
                              </h2>
                              {["URGENTE", "ALTA"].includes(tarefa.prioridade) ? (
                                <Badge className={prioridadeConfig.badgeClassName}>
                                  {prioridadeConfig.label}
                                </Badge>
                              ) : null}
                              <Badge variant="outline">
                                {STATUS_TAREFA_CONFIG[tarefa.status].label}
                              </Badge>
                              {hasCadencia ? (
                                <Badge className="bg-[#E8EEFB] text-[#1E4FAB] hover:bg-[#E8EEFB]">
                                  Cadencia
                                </Badge>
                              ) : null}
                            </div>
                            <p className="mt-1 text-sm text-[#667085]">
                              {tarefa.responsavel?.nome ?? "Sem responsavel"}
                            </p>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {contextBadges.length === 0 ? (
                                <span className="rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
                                  Sem contexto comercial
                                </span>
                              ) : (
                                contextBadges.map((badge) => (
                                  <span
                                    key={`${tarefa.id}-${badge.icon}-${badge.label}`}
                                    className="max-w-full truncate rounded-full bg-[#F4F6FA] px-2.5 py-1 text-xs font-semibold text-[#1A2E5A]"
                                  >
                                    {badge.icon} {badge.label}
                                  </span>
                                ))
                              )}
                            </div>
                            <p
                              className={cn(
                                "mt-2 flex items-center gap-2 text-sm font-semibold",
                                prazoClassName,
                              )}
                            >
                              <Clock3 className="size-4" />
                              {formatDate(tarefa.dataVencimento)}
                              {tarefa.horaVencimento
                                ? ` · ${tarefa.horaVencimento}`
                                : ""}
                            </p>
                            {tarefa.observacoes ? (
                              <details className="mt-3 text-sm text-[#667085]">
                                <summary className="cursor-pointer font-semibold text-[#1E4FAB]">
                                  Observacoes
                                </summary>
                                <p className="mt-1 leading-6">{tarefa.observacoes}</p>
                              </details>
                            ) : null}
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {!isConcluida ? (
                            <Button
                              type="button"
                              variant="outline"
                              className="rounded-2xl border-[#1E4FAB] text-[#1E4FAB] hover:bg-[#E8EEFB]"
                              onClick={() => openConcluir(tarefa)}
                            >
                              {hasCadencia ? "Concluir / Cadencia" : "Concluir"}
                            </Button>
                          ) : null}
                          {!tarefa.oportunidadeId ? (
                            <Button
                              type="button"
                              variant="outline"
                              className="rounded-2xl border-[#D7DEEA] text-[#1E4FAB] hover:border-[#1E4FAB] hover:text-[#1A2E5A]"
                              onClick={() => handleConverterEmOportunidade(tarefa)}
                            >
                              Converter em oportunidade
                            </Button>
                          ) : null}
                          <Button
                            type="button"
                            variant="outline"
                            className="rounded-2xl"
                            onClick={() => openEdit(tarefa)}
                          >
                            <Edit className="size-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="rounded-2xl text-red-700 hover:text-red-800"
                            onClick={() => deleteTarefa(tarefa)}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                          {/* Botão de histórico */}
                          <Button
                            type="button"
                            variant="outline"
                            className={cn(
                              "rounded-2xl gap-1.5",
                              tarefaExpandidaId === tarefa.id && "bg-[#E8EEFB] border-[#1E4FAB] text-[#1E4FAB]"
                            )}
                            onClick={() => toggleHistorico(tarefa.id)}
                            title="Ver histórico completo"
                          >
                            <History className="size-4" />
                            {tarefaExpandidaId === tarefa.id
                              ? <ChevronDown className="size-3" />
                              : <ChevronRight className="size-3" />}
                          </Button>
                        </div>
                      </div>

                      {/* ── Histórico expandido inline ── */}
                      {tarefaExpandidaId === tarefa.id && (
                        <div className="mt-4 border-t border-[#E8EDF5] pt-4">
                          <p className="mb-3 text-[10px] font-bold uppercase tracking-widest text-[#98A2B3]">
                            Histórico completo
                          </p>
                          {carregandoHistorico[tarefa.id] ? (
                            <div className="flex items-center gap-2 text-sm text-[#98A2B3]">
                              <Loader2 className="size-4 animate-spin" />
                              Carregando histórico...
                            </div>
                          ) : !historicos[tarefa.id] || historicos[tarefa.id].length === 0 ? (
                            <p className="text-sm text-[#98A2B3]">Nenhum evento registrado ainda.</p>
                          ) : (
                            <ol className="relative ml-3 border-l border-[#D7DEEA]">
                              {[...historicos[tarefa.id]].reverse().map((evento, idx) => {
                                const dt = new Date(evento.data);
                                const dtFormatada = new Intl.DateTimeFormat("pt-BR", {
                                  day: "2-digit",
                                  month: "2-digit",
                                  year: "2-digit",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                }).format(dt);
                                return (
                                  <li key={evento.id} className={cn("relative pl-5 pb-4", idx === 0 && "font-medium")}>
                                    {/* Ponto na linha do tempo */}
                                    <span className="absolute -left-[9px] top-0.5 flex size-[18px] items-center justify-center rounded-full border-2 border-white bg-[#F4F6FA] text-[10px]">
                                      {evento.icone}
                                    </span>
                                    <p className="text-sm text-[#1A2E5A]">{evento.descricao}</p>
                                    <p className="mt-0.5 text-[11px] text-[#98A2B3]">
                                      {evento.usuario ? `${evento.usuario} · ` : ""}{dtFormatada}
                                    </p>
                                  </li>
                                );
                              })}
                            </ol>
                          )}
                        </div>
                      )}
                    </article>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <TarefaModal
        aberto={modalAberto}
        tarefa={tarefaEditando}
        onFechar={() => setModalAberto(false)}
        onSalvar={loadTarefas}
      />
      <OportunidadeModal
        aberto={oportunidadeModalAberto}
        onFechar={closeOportunidadeModal}
        onSalvar={async (oportunidade) => {
          if (!tarefaConvertendo) {
            closeOportunidadeModal();
            return;
          }

          const response = await fetch(`/api/tarefas/${tarefaConvertendo.id}`, {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              oportunidadeId: oportunidade.id,
            }),
          });

          if (!response.ok) {
            toast.error("Oportunidade criada, mas nao foi possivel vincular a tarefa.");
          } else {
            toast.success("Oportunidade criada e tarefa vinculada.");
          }

          closeOportunidadeModal();
          await loadTarefas();
        }}
        statusInicial="NOVA"
        prefill={prefillOportunidade ?? undefined}
      />
      <ConcluirTarefaDialog
        aberto={concluirDialogOpen}
        tarefa={tarefaConcluindo}
        onFechar={() => setConcluirDialogOpen(false)}
        onConcluido={loadTarefas}
      />
    </main>
  );
}
